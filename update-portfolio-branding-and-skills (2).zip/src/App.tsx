import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Gamepad2,
  Code2,
  Bot,
  Users,
  Shield,
  ShieldCheck,
  Music,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ChevronRight,
  Star,
  Terminal,
  Zap,
  Lock,
  BarChart3,
  ExternalLink,
  Globe
} from 'lucide-react';

// Discord Icon SVG Component
function DiscordIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
    </svg>
  );
}

// LA Time Hook
function useLATime() {
  const [time, setTime] = useState(() => new Date());

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const laTime = new Date(time.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' }));
  const hours = laTime.getHours();
  const minutes = laTime.getMinutes();
  const seconds = laTime.getSeconds();

  const formatted = laTime.toLocaleTimeString('en-US', {
    timeZone: 'America/Los_Angeles',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });

  let period = '';
  let isAsleep = false;

  if (hours >= 5 && hours < 12) {
    period = 'Morning';
  } else if (hours >= 12 && hours < 17) {
    period = 'Afternoon';
  } else if (hours >= 17 && hours < 20) {
    period = 'Evening';
  } else if (hours >= 20 && hours < 23) {
    period = 'Night';
  } else {
    period = 'Midnight';
  }

  // Asleep 11PM (23:00) to 5AM (05:00)
  if (hours >= 23 || hours < 5) {
    isAsleep = true;
  }

  return { formatted, period, isAsleep, hours, minutes, seconds };
}

// Music Player using Web Audio API for a chill ambient drone
function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.25);
  const [autoPlayAttempted, setAutoPlayAttempted] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscillatorsRef = useRef<OscillatorNode[]>([]);
  const gainNodesRef = useRef<GainNode[]>([]);
  const masterGainRef = useRef<GainNode | null>(null);

  const buildAudio = useCallback((muted: boolean, vol: number) => {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const audioCtx = new AudioContextClass();
    audioCtxRef.current = audioCtx;

    const masterGain = audioCtx.createGain();
    masterGain.gain.value = muted ? 0 : vol;
    masterGain.connect(audioCtx.destination);
    masterGainRef.current = masterGain;

    // Chill ambient chord: D minor 9 (D, F, A, C, E)
    const frequencies = [146.83, 174.61, 220.00, 261.63, 329.63];

    frequencies.forEach((freq, i) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.value = freq;
      gain.gain.value = 0.05 / frequencies.length;

      osc.connect(gain);
      gain.connect(masterGain);

      const lfo = audioCtx.createOscillator();
      const lfoGain = audioCtx.createGain();
      lfo.frequency.value = 0.1 + i * 0.03;
      lfoGain.gain.value = 0.02;
      lfo.connect(lfoGain);
      lfoGain.connect(gain.gain);
      lfo.start();

      osc.start();
      oscillatorsRef.current.push(osc);
      gainNodesRef.current.push(gain);
    });

    return audioCtx;
  }, []);

  // Auto-play on first user interaction
  useEffect(() => {
    if (autoPlayAttempted) return;

    const tryAutoPlay = () => {
      if (autoPlayAttempted || audioCtxRef.current) return;
      setAutoPlayAttempted(true);

      try {
        const ctx = buildAudio(false, volume);
        if (ctx.state === 'running') {
          setIsPlaying(true);
          setIsMuted(false);
        }
      } catch {
        // Auto-play blocked, user will click manually
      }

      document.removeEventListener('click', tryAutoPlay);
      document.removeEventListener('keydown', tryAutoPlay);
      document.removeEventListener('scroll', tryAutoPlay);
      document.removeEventListener('touchstart', tryAutoPlay);
    };

    // Try immediately (works on some browsers)
    try {
      const ctx = buildAudio(false, volume);
      if (ctx.state === 'running') {
        setIsPlaying(true);
        setIsMuted(false);
        setAutoPlayAttempted(true);
      } else {
        // Suspended — wait for gesture
        document.addEventListener('click', tryAutoPlay, { once: true });
        document.addEventListener('keydown', tryAutoPlay, { once: true });
        document.addEventListener('scroll', tryAutoPlay, { once: true });
        document.addEventListener('touchstart', tryAutoPlay, { once: true });
      }
    } catch {
      document.addEventListener('click', tryAutoPlay, { once: true });
    }

    return () => {
      document.removeEventListener('click', tryAutoPlay);
      document.removeEventListener('keydown', tryAutoPlay);
      document.removeEventListener('scroll', tryAutoPlay);
      document.removeEventListener('touchstart', tryAutoPlay);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const togglePlay = useCallback(() => {
    if (!audioCtxRef.current) {
      buildAudio(false, volume);
      setIsPlaying(true);
      setIsMuted(false);
      return;
    }

    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }

    setIsPlaying(prev => {
      const next = !prev;
      if (masterGainRef.current && audioCtxRef.current) {
        masterGainRef.current.gain.setTargetAtTime(
          next ? volume : 0,
          audioCtxRef.current.currentTime,
          0.3
        );
      }
      setIsMuted(!next);
      return next;
    });
  }, [buildAudio, volume]);

  const toggleMute = useCallback(() => {
    if (!audioCtxRef.current) {
      buildAudio(false, volume);
      setIsPlaying(true);
      setIsMuted(false);
      return;
    }

    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }

    setIsMuted(prev => {
      const next = !prev;
      if (masterGainRef.current && audioCtxRef.current) {
        masterGainRef.current.gain.setTargetAtTime(
          next ? 0 : volume,
          audioCtxRef.current.currentTime,
          0.3
        );
      }
      setIsPlaying(!next);
      return next;
    });
  }, [buildAudio, volume]);

  useEffect(() => {
    if (masterGainRef.current && audioCtxRef.current && isPlaying && !isMuted) {
      masterGainRef.current.gain.setTargetAtTime(volume, audioCtxRef.current.currentTime, 0.1);
    }
  }, [volume, isMuted, isPlaying]);

  return (
    <div className="fixed bottom-6 right-6 z-50 music-player rounded-2xl p-3 shadow-2xl animate-fade-in-up">
      <div className="flex items-center gap-3">
        <button
          onClick={togglePlay}
          className="btn-primary w-10 h-10 rounded-full flex items-center justify-center text-white"
          aria-label={isPlaying ? 'Pause music' : 'Play music'}
        >
          {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
        </button>

        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <Music size={14} className="text-purple-400" />
            <span className="text-xs font-medium text-white/90">Chill Vibes</span>
          </div>
          <span className="text-[10px] text-white/50">
            {isPlaying ? 'Playing' : 'Paused'}
          </span>
        </div>

        <button
          onClick={toggleMute}
          className="w-8 h-8 rounded-full btn-secondary flex items-center justify-center text-white/70 hover:text-white"
          aria-label={isMuted ? 'Unmute' : 'Mute'}
        >
          {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>

        {isPlaying && !isMuted && (
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volume}
            onChange={(e) => {
              const v = parseFloat(e.target.value);
              setVolume(v);
              if (masterGainRef.current && audioCtxRef.current) {
                masterGainRef.current.gain.setTargetAtTime(v, audioCtxRef.current.currentTime, 0.05);
              }
            }}
            className="w-16 h-1 accent-purple-500 bg-white/10 rounded-lg cursor-pointer"
            aria-label="Volume"
          />
        )}
      </div>
    </div>
  );
}

const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'skills', label: 'Skills' },
  { id: 'projects', label: 'Projects' },
  { id: 'current', label: 'Current Projects' },
  { id: 'rift', label: 'Rift' },
  { id: 'contact', label: 'Contact' }
];

const skills = [
  {
    name: 'Roblox Studio',
    icon: <Gamepad2 size={28} strokeWidth={1.5} />,
    description: 'Building immersive Roblox experiences, game mechanics, and interactive worlds.'
  },
  {
    name: 'Luau Advanced Scripting',
    icon: <Code2 size={28} strokeWidth={1.5} />,
    description: 'Advanced Luau programming for game systems, modules, and optimized performance.'
  },
  {
    name: 'Discord Bot Development',
    icon: <Bot size={28} strokeWidth={1.5} />,
    description: 'Custom Discord bots for moderation, automation, and community engagement.'
  },
  {
    name: 'Community Management Systems',
    icon: <Users size={28} strokeWidth={1.5} />,
    description: 'Tools and systems for managing, growing, and moderating online communities.'
  },
  {
    name: 'Security Systems',
    icon: <Shield size={28} strokeWidth={1.5} />,
    description: 'Robust security architectures to protect games, servers, and user data.'
  },
  {
    name: 'Anti-Cheat Development',
    icon: <ShieldCheck size={28} strokeWidth={1.5} />,
    description: 'Proactive anti-exploit and anti-cheat solutions for fair gameplay.'
  }
];

const projects = [
  {
    title: 'Roblox Games & Groups',
    category: 'Roblox Development',
    icon: <Gamepad2 size={24} />,
    description: 'A portfolio of Roblox games and group projects spanning multiple genres and systems — from scripted gameplay mechanics to group management tooling. 7,000+ combined visits across all experiences.',
    stats: '7,000+ combined visits',
    tags: ['Roblox Studio', 'Luau', 'Groups', 'Game Design']
  },
  {
    title: 'Anti-Exploit Framework',
    category: 'Security System',
    icon: <ShieldCheck size={24} />,
    description: 'A server-side and client-side anti-exploit framework designed to detect and mitigate common Roblox cheating methods.',
    stats: 'Production ready',
    tags: ['Luau', 'Security', 'Anti-Cheat']
  },
  {
    title: 'Server Protection Suite',
    category: 'Security System',
    icon: <Lock size={24} />,
    description: 'Multi-layered protection systems for Roblox experiences including anti-spam, rate limiting, and anomaly detection.',
    stats: 'Enterprise grade',
    tags: ['Security', 'Luau', 'Monitoring']
  },
  {
    title: 'Community Dashboard',
    category: 'Community Management Tool',
    icon: <BarChart3 size={24} />,
    description: 'A web-based dashboard for tracking community growth, server health, and automated moderation actions.',
    stats: 'Real-time analytics',
    tags: ['Systems', 'Analytics', 'Management']
  },
  {
    title: 'Roblox Tycoon System',
    category: 'Roblox Game',
    icon: <Zap size={24} />,
    description: 'A modular tycoon framework with save systems, upgrades, and monetization integration.',
    stats: '5,000+ plays',
    tags: ['Roblox Studio', 'Luau', 'Economy']
  }
];

const riftTimeline = [
  { year: '2026', title: 'Joined Rift', description: 'Started my journey with Rift this year, contributing to its community and systems.' }
];

export default function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { formatted: laTime, period, isAsleep } = useLATime();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveTab(id);
      setMobileMenuOpen(false);
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map(item => document.getElementById(item.id));
      const scrollPosition = window.scrollY + 100;

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i];
        if (section && section.offsetTop <= scrollPosition) {
          setActiveTab(navItems[i].id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-transparent text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-[#0f0518]/80 backdrop-blur-xl border-b border-white/5">
        <div className="section-container">
          <div className="flex items-center justify-between h-16 md:h-20">
            <button
              onClick={() => scrollToSection('home')}
              className="flex items-center gap-3 group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center group-hover:shadow-lg group-hover:shadow-purple-500/30 transition-all">
                <Terminal size={20} className="text-white" />
              </div>
              <span className="font-bold text-lg tracking-tight">b0pfq</span>
            </button>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1 bg-white/5 rounded-full p-1 border border-white/5">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    activeTab === item.id
                      ? 'nav-active text-white'
                      : 'text-white/60 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden w-10 h-10 rounded-xl btn-secondary flex items-center justify-center"
            >
              <div className="flex flex-col gap-1.5">
                <span className={`w-5 h-0.5 bg-white transition-all ${mobileMenuOpen ? 'rotate-45 translate-y-2' : ''}`} />
                <span className={`w-5 h-0.5 bg-white transition-all ${mobileMenuOpen ? 'opacity-0' : ''}`} />
                <span className={`w-5 h-0.5 bg-white transition-all ${mobileMenuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#0f0518]/95 backdrop-blur-xl border-b border-white/5 animate-fade-in-up">
            <div className="section-container py-4 flex flex-col gap-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-4 py-3 rounded-xl text-left text-sm font-medium transition-all ${
                    activeTab === item.id
                      ? 'nav-active text-white'
                      : 'text-white/60 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center pt-20 relative overflow-hidden">
        <div className="section-container w-full">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div className="space-y-8 animate-fade-in-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-sm font-medium">
                <Star size={14} className="text-purple-400" />
                <span>Roblox Scripter & Systems Developer</span>
              </div>

              <div>
                <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-4">
                  <span className="text-white">Hi, I'm </span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-violet-400 to-purple-300 glow-text">b0pfq</span>
                </h1>
                <p className="text-xl md:text-2xl text-white/70 font-light leading-relaxed max-w-xl">
                  I build robust Roblox systems, Discord bots, anti-cheat solutions, and community management tools.
                </p>
              </div>

              <p className="text-white/50 max-w-lg leading-relaxed">
                With nearly 4 years of experience, I've shipped 32+ projects spanning Roblox games, Discord bots, security systems, and community management platforms. I specialize in turning complex ideas into clean, optimized systems.
              </p>

              <div className="flex items-center gap-2 text-purple-300/80 text-sm font-medium">
                <Globe size={16} />
                <span>Primary Link Hub:</span>
                <a 
                  href="https://blitz.rift.baby" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-white hover:text-purple-300 underline underline-offset-4 transition-colors font-mono"
                >
                  blitz.rift.baby
                </a>
              </div>

              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => scrollToSection('projects')}
                  className="btn-primary px-8 py-4 rounded-full font-semibold flex items-center gap-2 text-white"
                >
                  View My Work
                  <ChevronRight size={18} />
                </button>
                <button
                  onClick={() => scrollToSection('contact')}
                  className="btn-secondary px-8 py-4 rounded-full font-semibold flex items-center gap-2 text-white"
                >
                  <DiscordIcon className="w-5 h-5" />
                  Contact on Discord
                </button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                {[
                  { value: '32+', label: 'Projects' },
                  { value: '7K+', label: 'Roblox Visits' },
                  { value: '4', label: 'Years Experience' }
                ].map((stat, index) => (
                  <div key={index} className="gradient-border p-4 text-center card-hover">
                    <div className="text-2xl md:text-3xl font-bold text-white">{stat.value}</div>
                    <div className="text-xs md:text-sm text-white/50">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Discord Profile Picture Placeholder */}
            <div className="relative flex justify-center lg:justify-end animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              <div className="relative">
                <div className="absolute inset-0 bg-purple-600/30 rounded-full blur-3xl animate-pulse-glow" />
                <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-purple-500/30 shadow-2xl animate-float">
                  <img
                    src="https://plain-wnam-prod-public.komododecks.com/202606/15/7njD7REoRsW5L7qyclCC/image.jpg"
                    alt="b0pfq Discord Profile Picture"
                    className="w-full h-full object-cover object-center"
                  />
                </div>
                <div className="absolute -bottom-2 -right-2 w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center border-4 border-[#0f0518] shadow-lg">
                  <DiscordIcon className="w-8 h-8 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Background decoration */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-24 md:py-32 relative">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Technical Skills</h2>
            <p className="text-white/50 max-w-2xl mx-auto">
              My expertise is focused on the Roblox ecosystem, Discord automation, and security systems.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill, index) => (
              <div
                key={skill.name}
                className="gradient-border p-8 card-hover text-center"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="skill-icon-container text-purple-300">
                  {skill.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{skill.name}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{skill.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 md:py-32 relative">
        <div className="section-container">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Featured Projects</h2>
            <p className="text-white/50 max-w-2xl mx-auto">
              A selection of my work across Roblox games, Discord bots, anti-cheat systems, and community management tools.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <div
                key={project.title}
                className="gradient-border p-6 card-hover flex flex-col h-full"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-300">
                    {project.icon}
                  </div>
                  <span className="text-xs font-medium text-purple-300 bg-purple-500/10 px-3 py-1 rounded-full">
                    {project.category}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed mb-4 flex-grow">{project.description}</p>
                <div className="text-xs font-semibold text-purple-300 mb-4">{project.stats}</div>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span key={tag} className="text-xs text-white/40 bg-white/5 px-2 py-1 rounded-md border border-white/5">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Current Projects Section */}
      <section id="current" className="py-24 md:py-32 relative">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">Current Projects</h2>
              <p className="text-white/50">Active developments and communities I'm currently contributing to.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Ashville State Roleplay Community */}
              <div className="gradient-border p-8 card-hover relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <Globe size={80} />
                </div>
                <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mb-6 text-purple-300">
                  <Users size={32} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Ashville State Roleplay Community</h3>
                <p className="text-white/50 text-sm leading-relaxed mb-6">
                  Currently serving as a **Trial Developer**. Providing systems development and contributing to community management infrastructure.
                </p>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
                  <span className="text-xs font-semibold text-yellow-400 tracking-wider uppercase">Trial Developer</span>
                </div>
              </div>

              {/* Florida State Roleplay Community */}
              <div className="gradient-border p-8 card-hover relative group overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <Zap size={80} />
                </div>
                <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mb-6 text-purple-300">
                  <Gamepad2 size={32} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Florida State Roleplay Community</h3>
                <p className="text-white/50 text-sm leading-relaxed mb-6">
                  Focusing on Luau scripting for specialized game mechanics, emergency services systems, and community tools.
                </p>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs font-semibold text-green-400 tracking-wider uppercase">Active Development</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Rift Section */}
      <section id="rift" className="py-24 md:py-32 relative">
        <div className="section-container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-[#5865F2]/20 border border-[#5865F2]/30 mb-6">
                <DiscordIcon className="w-10 h-10 text-[#5865F2]" />
              </div>
              <h2 className="text-3xl md:text-5xl font-bold mb-4">Rift</h2>
              <p className="text-white/50 max-w-2xl mx-auto">
                A Discord-focused community and development journey.
              </p>
            </div>

            <div className="relative">
              <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-purple-500/50 via-purple-500/20 to-transparent" />
              
              {riftTimeline.map((item, index) => (
                <div
                  key={index}
                  className={`relative flex items-center gap-8 mb-12 ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                >
                  <div className="hidden md:block w-1/2 text-right">
                    {index % 2 === 0 && (
                      <div className="gradient-border p-6 inline-block text-left card-hover">
                        <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                        <p className="text-white/50 text-sm">{item.description}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-purple-500 border-4 border-[#0f0518] shadow-lg shadow-purple-500/50" />
                  
                  <div className="hidden md:block w-1/2">
                    {index % 2 !== 0 && (
                      <div className="gradient-border p-6 inline-block card-hover">
                        <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                        <p className="text-white/50 text-sm">{item.description}</p>
                      </div>
                    )}
                  </div>

                  {/* Mobile layout */}
                  <div className="md:hidden pl-16 w-full">
                    <div className="gradient-border p-6 card-hover">
                      <div className="text-purple-400 font-bold text-sm mb-2">{item.year}</div>
                      <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                      <p className="text-white/50 text-sm">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}

            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 md:py-32 relative">
        <div className="section-container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">Get In Touch</h2>
              <p className="text-white/50 max-w-2xl mx-auto">
                Discord is my preferred contact method. Reach out for collaborations, commissions, or just to chat.
              </p>
            </div>

            <div className="gradient-border p-8 md:p-12 card-hover">
              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 rounded-3xl bg-[#5865F2]/20 border border-[#5865F2]/30 flex items-center justify-center mb-8">
                  <DiscordIcon className="w-12 h-12 text-[#5865F2]" />
                </div>

                <h3 className="text-2xl md:text-3xl font-bold text-white mb-6">Discord</h3>

                <div className="space-y-4 w-full max-w-md mb-8">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
                    <span className="text-white/50 text-sm">Username</span>
                    <span className="text-white font-mono font-semibold">b0pfq</span>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5">
                    <span className="text-white/50 text-sm">Discord ID</span>
                    <span className="text-white font-mono font-semibold text-sm md:text-base">1387045742484656249</span>
                  </div>
                </div>

                <a
                  href="https://discord.com/users/1387045742484656249"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary px-8 py-4 rounded-full font-semibold inline-flex items-center gap-3 text-white"
                >
                  <DiscordIcon className="w-5 h-5" />
                  Message on Discord
                  <ExternalLink size={16} />
                </a>

                <p className="text-white/30 text-xs mt-6">
                  Note: You may need to share a server or enable DMs to message this user.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/5">
        <div className="section-container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-600 to-purple-900 flex items-center justify-center">
                <Terminal size={16} className="text-white" />
              </div>
              <span className="font-bold text-white">b0pfq</span>
            </div>

            {/* LA Time Display */}
            <div className="flex flex-col items-center gap-1">
              <div className="flex items-center gap-2 text-white/80 font-mono text-sm font-semibold">
                <span className="text-purple-400 text-base">🕐</span>
                <span>{laTime}</span>
                <span className="text-purple-300 font-sans font-normal text-xs">Los Angeles</span>
              </div>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                  isAsleep
                    ? 'bg-red-500/15 text-red-400 border border-red-500/20'
                    : 'bg-green-500/15 text-green-400 border border-green-500/20'
                }`}>
                  {isAsleep ? '😴 Likely asleep' : `🟢 ${period}`}
                </span>
                {isAsleep && (
                  <span className="text-white/30 text-[10px]">Usually asleep 11 PM – 5 AM</span>
                )}
              </div>
            </div>

            <p className="text-white/40 text-sm text-center md:text-right">
              © {new Date().getFullYear()} Orbit Studios.<br className="hidden md:block" /> All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Music Player */}
      <MusicPlayer />
    </div>
  );
}
